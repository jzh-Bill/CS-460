Hi Dr.Kafi, my name is Zhihao Jin, the developer of this assignment. 
ID number: 001360171
E-mail: zj8847@truman.edu
JDK: The 8v OS: Windos 10 64x


How to setup:
1: Create a java project which depends on JOGL souce code in Eclispe.
2: Create a package named: com.drawing
3: Copy and paste all the java files in that package.

Other comments:
In my own opinion, the whole project looks great - well commenting, good classes, and animating.  
Based on the whole assignment, there is some redundant code you may have already noticed, in the 
GCircle the method "drawoutline" will not be used; thus I did not put this in the render method. 
But I kept them rather than deleted since I may use them in one day. 
Also, there are some dummy data in parameter in order to fit and not change the original method constructors. 
I would say the whole drawing is great, which looks really similar to the given picture. 
The 98% of the total scores will be given by myself if there are no other big issues. 