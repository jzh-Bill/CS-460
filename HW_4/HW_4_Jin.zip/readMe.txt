Hi Dr.Kafi, my name is Zhihao Jin, the developer of this assignment. 
ID number: 001360171
E-mail: zj8847@truman.edu
JDK: The 8v OS: Windos 10 64x


How to setup:
1: Create a java project which depends on JOGL source code in Eclispe.
2: Named the project: GSpriteCollision
3: Copy and put the "src" folder from the given "Code" zip file in that project.
3: Copy and put the "World" folder from the given "Code" zip file in that project where you keep "src".

Other comments:
In my own opinion, the whole project looks great - well commenting, good classes, and animating.  
Based on the whole assignment, there is some redundant code you may have already noticed, in the 
GCRect, the method "drawoutline" and "Fill"will not be used; thus I did not put this in the render method. 
But I kept them rather than deleted since I may use them in one day. 

By comparing with 3nd assigment, this assgiemnt changed the size of showing windows which is 700 width and 1100 hight.
Second, in order to control the some of the objects in file, they may have multiple constructors.
Third, in this assigment, there are 5 animated textured objects: The sea(at bottom of the screen), dragon, hot air ballon, Dino(the dinosaur), and the plane.
Some of them are initialzed in flater file, which also contains other different objects initlized in there as well.
The animation video is contained in this zip file.
The congratulation sign will be printed in the console, but has not been shown in the clip.
Also, there are some dummy data in parameter in order to fit and not change the original method constructors. 
I would say the whole drawing is great, which looks really similar to the given picture. 
The 98% of the total scores will be given by myself if there are no other big issues. 