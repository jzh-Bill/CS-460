package com.drawing;

import com.jogamp.opengl.GL2;

// draws nothing, placeholder for the root node
public class GEmptyShape implements GShape {
	
	public void render(final GL2 gl)
	{

	}

}
