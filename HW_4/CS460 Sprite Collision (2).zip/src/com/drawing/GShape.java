package com.drawing;

import com.jogamp.opengl.GL2;

public interface GShape {

	public void render(final GL2 gl);

	// boolean isCollision(Point p);

}
